return {
	name = 'Particles',
	config = '',
	platform = 'win64',
	version = '1.1',
	love = '11.5'
}